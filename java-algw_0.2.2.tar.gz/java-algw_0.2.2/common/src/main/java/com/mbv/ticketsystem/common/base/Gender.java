package com.mbv.ticketsystem.common.base;

public enum Gender {
    MALE, FEMALE
}
