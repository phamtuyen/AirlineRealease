package com.mbv.ticketsystem.common.airline;

public enum AirPassengerType {
    ADT, CHD, INF
}
