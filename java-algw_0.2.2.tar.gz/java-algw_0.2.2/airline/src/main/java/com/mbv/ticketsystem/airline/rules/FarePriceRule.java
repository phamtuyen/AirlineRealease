package com.mbv.ticketsystem.airline.rules;


public abstract class FarePriceRule {
    public abstract void apply(Object object);
}
